
# Multipath NFS client source

This is a source package for extending the NFS client, that can build based on 
kernel and distribution detection. Multiple kernels are supported by this package.
This source package is licensed under GPLv2.0 and any modifications made to this 
source by Dell Technologies were made for ease of use and chain-of-custody security review.

# Building & Installing the Driver

For the most detailed instructions and KB articles, see our guide for installation and configuration here:
https://www.dell.com/support/home/en-us/product-support/product/isilon-onefs/docs

and search for "Multipath Driver".

## Why Build?

Any minor version kernel mismatch on the client results in the driver not installing correctly. For example, `5.4.0-150-generic` is incompatible with `5.4.0-167-generic`. Needless to say, both are incompatible with `5.15.0-91-generic`, which has an upgraded kernel.

Unless you know all of your clients are identical, you should build and install the driver per-client, or you may get failed installs.

## Dependencies to Install First

| Operating System | Command |
| ---------------- | ------- |
| **Debian**       | `sudo apt-get install debhelper` |
| **CentOS/RHEL**  | `sudo yum install -y rpm-build kernel-devel-$(uname -r)` |
| **OpenSUSE/SLES**| `zypper install rpmbuild tar gzip git kernel-devel` (see special build prep section for SUSE) |

Building experience may vary depending on which libraries, and compilers are provided on your system.

### OpenSUSE/SLES kernel-devel

According to OpenSUSE documentation, use:
```sh
zypper install kernel-default-devel
```
This sometimes DOES NOT install the correct kernel-devel package. You can check this by looking at the following paths:

```sh
# ls /lib/modules/
5.14.21-150500.55.39-default
``` 
```sh
# uname -a
Linux 6f8edb8b881a 5.15.0-91-generic
```
Notice the contents of /lib/modules does not match our uname: 5.14.21-150500.55.39-default != 5.15.0-91-generic.
The client-side driver will then fail with the following error:
```sh
# ls -alh /lib/modules/$(uname -r)/build
ls: cannot access '/lib/modules/5.14.21-150400.24.63-default/build': No such file or directory
....
Kernel root not found
```
To fix, select the correct package with:
``` sh
# rpm -qf /lib/modules/$(uname -r)/
kernel-default-5.14.21-150400.24.63.1.x86_64
kernel-default-extra-5.14.21-150400.24.63.1.x86_64
kernel-default-optional-5.14.21-150400.24.63.1.x86_64
```
Then install:
```sh
# zypper install kernel-default-devel-5.14.21-150400.24.63.1.x86_64
```

## Building The Binary package

To build a binary from this source package for the current kernel and OFED
versions, run `./build.sh bin`, and take the output from the `dist` directory.
If the kernel, distribution, or OFED are not supported, an error will be
printed.

```plaintext
   $ ./build.sh bin
   ...
dpkg-buildpackage: info: binary-only upload (no source included)
total 1048
-rw-r--r-- 1 root root 1071888 Aug  7 03:25 dellnfs-modules_4.0.30-Dell-Technologies.kver.5.15.0-117-generic_amd64.deb
------------------------------------------------------------------

Output in dist/

total 1048
```

# Install

Install can be performed by the default package manager on each system:

| Operating System | Command                                                                                                    | Additional Steps                              |
| ---------------- | ---------------------------------------------------------------------------------------------------------- | ----------------------------------------------|
| **OpenSUSE/SLES**| `zypper install ./dist/dellnfs-kernel-default-devel-5.14.21-150400.24.63.1.x86_64`                         | `reboot`                                      |
| **RHEL 8.x/9.x** | `yum install ./dist/dellnfs-4.0.30-MLNX_OFED_LINUX.5.9.0.5.6.0_kernel_5.14.0_284.11.1.el9_2.x86_64.rpm`    | `dracut -f` followed by `reboot`              |
| **Debian**       | `apt install ./dist/dellnfs-modules_4.0.30-Dell-Technologies.kver.5.15.0-117-generic_amd64.deb`            | `update-initramfs -u -k \`uname -r\`          |
| **DKMS**         | `apt install ./dist/dellnfs-dkms_4.5-OFED.4.5.1.0.1.1.gb4fdfac.multikel_all.deb`                           | `dkms install -m dellnfs -v 99.4.5`, `reboot` |

## Verifying installation
Check driver status with the following command:

```sh
# dellnfs-ctl status
version: 4.0.30
kernel modules: sunrpc rpcrdma compat_nfs_ssc lockd nfs_acl nfs nfsv3
services: rpcbind.socket rpcbind
```
This will show NFS kernel modules loaded, and for each kernel module, the multipath driver should provide that module:

### Debian

The driver should now provide common kernel modules, such as rpcrdma.ko:
```sh
–dpkg -l | grep dellnfs-modules
Example: ii  dellnfs-modules   2:4.0.30-dell.kver.5.4.0-150-generic amd64        NFS RDMA kernel modules

–dpkg -S /lib/modules/`uname -r`/updates/bundle/net/sunrpc/xprtrdma/rpcrdma.ko
Example: dellnfs-modules: /lib/modules/5.4.0-150-generic/updates/bundle/net/sunrpc/xprtrdma/rpcrdma.ko
```
### RHEL / SUSE
```sh
modinfo rpcrdma
filename: /lib/modules/5.14.0-284.11.1.el9_2.x86_64/extra/dellnfs/bundle/net/sunrpc/xprtrdma/rpcrdma.ko 
```

Another way to check that the common module is now correctly provided by the driver:
```sh
rpm -qif /lib/modules/`uname -r`/extra/dellnfs/bundle/net/sunrpc/xprtrdma/rpcrdma.ko

Name        : dellnfs
Version     : 4.0.30
Release     : kernel_4.18.0_553.22.1.el8_10
Architecture: x86_64
Install Date: Mon 14 Oct 2024 11:50:05 PM EDT
Group       : System Environment/Base
Size        : 7979436
License     : GPLv2
Signature   : (none)
Source RPM  : dellnfs-4.0.30-kernel_4.18.0_553.22.1.el8_10.src.rpm
Build Date  : Mon 14 Oct 2024 11:48:09 PM EDT
Build Host  : rdma-rhel8-sriov.test.dell.com
Relocations : (not relocatable)
Vendor      : Dell-Technologies
URL         : http://www.mellanox.com
Summary     : dellnfs Driver
Description :
dellnfs kernel modules
```

## Debugging & Troubleshooting

If some common kernel modules are not being provided by `dellnfs`, you can check which ones by watching the output of:
```sh
dellnfs-ctl reload
```
This script will reload all nfs-related modules using 
```sh modprobe```

The script can also be invoked without an installation via the source path
`./scripts/multipath-ctl reload`.

If a particular module is failing to be provided, check for failure messages via `journalctl` or `dmesg`. Always ensure that the correct kernel version is being used, especially if you are using a built package on multiple clients.

For additional debugging information, please see our troubleshooting guide: https://www.dell.com/support/home/en-us/product-support/product/isilon-onefs/docs
