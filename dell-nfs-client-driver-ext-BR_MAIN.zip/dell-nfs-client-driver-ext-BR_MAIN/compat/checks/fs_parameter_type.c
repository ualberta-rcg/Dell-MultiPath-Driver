#include <linux/module.h>
#include <linux/fs_parser.h>

static enum fs_parameter_type x;

MODULE_LICENSE("GPL");
