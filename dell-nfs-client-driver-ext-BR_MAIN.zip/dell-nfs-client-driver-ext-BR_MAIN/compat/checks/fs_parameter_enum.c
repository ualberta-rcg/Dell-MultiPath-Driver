#include <linux/module.h>
#include <linux/fs_parser.h>

static struct fs_parameter_enum x;

MODULE_LICENSE("GPL");
