#include <linux/module.h>
#include <linux/filelock.h>

/* Exists since Linux v6.3 */

void test_dummy(void)
{
}

MODULE_LICENSE("GPL");
