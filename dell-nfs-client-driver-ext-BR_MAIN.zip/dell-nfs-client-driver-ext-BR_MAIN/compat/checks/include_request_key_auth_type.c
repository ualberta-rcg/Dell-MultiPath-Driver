#include "linux/module.h"
#include <keys/request_key_auth-type.h>

MODULE_LICENSE("GPL");
