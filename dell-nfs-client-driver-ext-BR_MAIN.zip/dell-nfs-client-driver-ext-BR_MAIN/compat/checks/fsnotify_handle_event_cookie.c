#include "linux/module.h"
#include "linux/fsnotify.h"

static inline int test_file_fsnotify_handle_event(struct fsnotify_mark *mark, u32 mask,
						  struct inode *inode, struct inode *dir,
						  const struct qstr *name, u32 cookie)
{
	return 0;
}

static const struct fsnotify_ops file_fsnotify_ops = {
	.handle_inode_event = test_file_fsnotify_handle_event,
};

void test_wrapper(void)
{
}

MODULE_LICENSE("GPL");
