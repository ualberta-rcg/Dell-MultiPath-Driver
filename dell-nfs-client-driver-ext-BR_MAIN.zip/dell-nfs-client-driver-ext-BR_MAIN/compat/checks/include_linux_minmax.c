#include <linux/module.h>
#include <linux/minmax.h>

void test_dummy(void)
{
}

MODULE_LICENSE("GPL");
